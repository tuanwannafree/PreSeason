#include <algorithm>
#include <bitset>
#include <cctype>
#include <cfloat>
#include <climits>
#include <cmath>
#include <complex>
#include <cstdio>
#include <cstdlib>
#include <cstring>
#include <ctime>
#include <deque>
#include <functional>
#include <iostream>
#include <list>
#include <map>
#include <numeric>
#include <queue>
#include <set>
#include <stack>
#include <string>
#include <utility>
#include <unordered_map>
#include <vector>
#define ll long long
#define pb push_back
#define _for(i,a,b) for(int i = a, i < b; i++)
#define _ford(i,a,b) for(int i = a, i > b; i--)
#define ln endl
using namespace std;

struct dic
{
    string english;
    string vietnamese;
    dic *pLeft;
    dic *pRight;
};

typedef dic *dicTree;

void CreateDictionary(dicTree &t)
{
    t = NULL;
}

dic* CreateWord(const string& eng, const string& vie)
{
    dic *p = new dic;
    if(p == NULL) return NULL;
    p->english = eng;
    p->vietnamese = vie;
    p->pLeft = NULL;
    p->pRight = NULL;
    return p;
}

int insertWord(dicTree &t, const string& eng, const string& vie)
{
    if(t != NULL)
    {
        if(t->english == eng)
        {
            return 0;
        }
        if(eng < t->english)
        {
            return insertWord(t->pLeft, eng, vie);
        }
        else
        {
            return insertWord(t->pRight, eng, vie);
        }
    }
    t = CreateWord(eng, vie);
    if(t == NULL) return -1;
    return 1;
}

dic* Search(dicTree t, const string& eng)
{
    if(t == NULL) return NULL;
    if(t->english == eng) return t;
    if(eng < t->english)
    {
        return Search(t->pLeft, eng);
    }
    else
    {
        return Search(t->pRight, eng);
    }
}

bool fixWord(dicTree t, const string& eng, const string& newVie)
{
    dic* word = Search(t, eng);
    if(word != NULL)
    {
        word->vietnamese = newVie;
        return true;
    }
    return false;
}

void printLNR(dicTree t)
{
    if(t != NULL)
    {
        printLNR(t->pLeft);
        cout << t->english << " : " << t->vietnamese << endl;
        printLNR(t->pRight);
    }
}

void deleteDic(dicTree &t)
{
    if(t != NULL)
    {
        deleteDic(t->pLeft);
        deleteDic(t->pRight);
        delete t;
        t = NULL;
    }
}

void ShowMenu() {
    cout << "\n===== TU DIEN ANH-VIET (BST) =====" << endl;
    cout << "1. Them tu moi" << endl;
    cout << "2. Tra cuu nghia" << endl;
    cout << "3. Sua nghia cua tu" << endl;
    cout << "4. In toan bo tu dien (A-Z)" << endl;
    cout << "0. Thoat chuong trinh" << endl;
    cout << "===================================" << endl;
    cout << "Nhap lua chon cua ban: ";
}

int main()
{
	dicTree t;
	CreateDictionary(t);
	int c;
	string english, vietnammese, newMeaning;
	dic* resSearch;
	insertWord(t, "hi", "xin chao");
	insertWord(t, "cat", "meo");
	insertWord(t, "dog", "cho");
	insertWord(t, "walk", "di");
	insertWord(t, "run", "chay");

    do {
        ShowMenu();
        cin >> c;
        cin.ignore(numeric_limits<streamsize>::max(), '\n');

        switch (c) {
            case 1:
                cout << "Nhap tu tieng Anh can them: ";
                getline(cin, english);
                cout << "Nhap nghia tieng Viet: ";
                getline(cin, vietnammese);
                {
                    int res = insertWord(t, english, vietnammese);
                    if (res == 1) {
                        cout << "Them tu thanh cong!" << endl;
                    } else if (res == 0) {
                        cout << "Loi: Tu '" << english << "' da ton tai!" << endl;
                    } else {
                         cout << "Loi: Khong the tao muc tu moi (loi bo nho?)" << endl;
                    }
                }
                break;
            case 2:
                cout << "Nhap tu tieng Anh can tra cuu: ";
                getline(cin, english);
                resSearch = Search(t, english);
                if (resSearch != NULL) {
                    cout << "Nghia cua '" << english << "' la: " << resSearch->vietnamese << endl;
                } else {
                    cout << "Khong tim thay tu '" << english << "' trong tu dien." << endl;
                }
                break;
            case 3:
                cout << "Nhap tu tieng Anh can sua nghia: ";
                getline(cin, english);
                cout << "Nhap nghia tieng Viet moi: ";
                getline(cin, newMeaning);
                if (fixWord(t, english, newMeaning)) {
                    cout << "Cap nhat nghia cho tu '" << english << "' thanh cong!" << endl;
                } else {
                    cout << "Loi: Khong tim thay tu '" << english<< "' de sua." << endl;
                }
                break;
            case 4:
                cout << "\n--- Danh sach tu dien (A-Z) ---" << endl;
                printLNR(t);
                if (t == NULL) {
                    cout << "(Tu dien rong)" << endl;
                }
                cout << "-------------------------------" << endl;
                break;
            case 0:
                cout << "Dang thoat chuong trinh..." << endl;
                break;
            default:
                cout << "Lua chon khong hop le. Vui long chon lai." << endl;
        }
        if (c != 0) {
             cout << "\nNhan Enter de tiep tuc...";
             cin.ignore(numeric_limits<streamsize>::max(), '\n');
        }

    } while (c != 0);


	deleteDic(t);
	return 0;
}
