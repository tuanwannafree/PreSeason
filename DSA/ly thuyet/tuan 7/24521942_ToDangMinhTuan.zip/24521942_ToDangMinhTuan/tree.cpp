#include <iostream>
#include <cmath>
#include <algorithm>
#include <vector>
using namespace std;

struct TNode {
    int key;
    TNode *pLeft;
    TNode *pRight;
};
typedef TNode *TREE;

void CreateTree(TREE &t);
TNode* CreateNode(int x);
int InsertNode(TREE &t, int x);
void Input(TREE &t, int &n);
void inorderLNR(TREE Root);
void postorderLRN(TREE Root);
void preorderNLR(TREE Root);
void NRL(TREE Root);
void RNL(TREE Root);
void RLN(TREE Root);
bool Search(TREE t, int x);
bool checkNodeSiblings(TREE t, int a, int b);
int cntNodes(TREE t);
int cntLeaf(TREE t);
int cnt1Child(TREE t);
int cntFullNode(TREE t);
int cntEven(TREE t);
int cntEvenLeaf(TREE t);
long long Sum(TREE t);
long long sum1(TREE t);
long long sum1Prime(TREE t);
int height(TREE t);
TNode* findMin(TREE t);
int DeleteNode(TREE &t, int x);
bool checkIndentical(TREE t1, TREE t2);



int main() {
TREE t = NULL;
    int n, x, a, b;
    Input(t, n);
    cout << "Inorder (LNR) traversal: ";
    inorderLNR(t);
    cout << "Postorder (LRN) traversal: ";
    postorderLRN(t);
    cout << "Preorder (NLR) traversal: ";
    preorderNLR(t);
    cout<< "NRL traversal: ";
    NRL(t);
    cout << "RNL traversal: ";
    RNL(t);
    cout << "RLN traversal: ";
    RLN(t);
    cout << "Enter a value to search: ";
    cin >> x;
    if (Search(t, x)) {
        cout << x << " is found in the tree." << endl;
    } else {
        cout << x << " is not found in the tree." << endl;
    }
    cout << "Enter two values to check if they are siblings: ";
    cin >> a >> b;
    if (checkNodeSiblings(t, a, b)) {
        cout << a << " and " << b << " are siblings." << endl;
    } else {
        cout << a << " and " << b << " are not siblings." << endl;
    }
    cout << "Number of nodes: " << cntNodes(t) << endl;
    cout << "Number of leaf nodes: " << cntLeaf(t) << endl;
    cout << "Number of nodes with one child: " << cnt1Child(t) << endl;
    cout << "Number of full nodes: " << cntFullNode(t) << endl;
    cout << "Number of even nodes: " << cntEven(t) << endl;
    cout<< "Number of even leaf nodes: " << cntEvenLeaf(t) << endl;
    cout << "Sum of all node values: " << Sum(t) << endl;
    cout << "Sum of nodes with one child: " << sum1(t) << endl;
    cout << "Sum of prime nodes with one child: " << sum1Prime(t) << endl;
    cout << "Height of the tree: " << height(t) << endl;
    TNode* minNode = findMin(t);
    if (minNode) {
        cout << "Minimum value in the tree: " << minNode->key << endl;
    } else {
        cout << "The tree is empty." << endl;
    }
    cout << "Enter a value to delete: ";
    cin >> x;
    if (DeleteNode(t, x)) {
        cout << x << " is deleted from the tree." << endl;
        cout << "Inorder traversal after deletion: ";
        inorderLNR(t);
    } else {
        cout << x << " is not found in the tree." << endl;
    }
    TREE t2 = NULL;
    Input(t2, n);

    if (checkIndentical(t, t2))
       cout << "The trees are identical." << endl;
    else
       cout << "The trees are not identical." << endl;

    return 0;
}

bool check(int n) {
    if (n <= 1) return false;
    if (n <= 3) return true;
    if (n % 2 == 0 || n % 3 == 0) return false;
    for (int i = 5; i * i <= n; i = i + 6) {
        if (n % i == 0 || n % (i + 2) == 0)
            return false;
    }
    return true;
}

void CreateTree(TREE &t) {
    t = NULL;
}

TNode* CreateNode(int x)
{
    TNode *p = new TNode;
    if(p == NULL) return NULL;
    p->key = x;
    p->pLeft = NULL;
    p->pRight = NULL;
    return p;
}

int InsertNode(TREE &t, int x)
{
    if(t != NULL)
    {
        if(t->key == x)
        {
            return 0;
        }
        if(t->key > x)
        {
            return InsertNode(t->pLeft, x);
        }
        else
        {
            return InsertNode(t->pRight, x);
        }

    }
    t = CreateNode(x);
    return 1;
}

void Input(TREE &t, int &n)
{
    cout << "Nhap so phan tu cay ";
    cin >> n;
    CreateTree(t);
    for(int i = 0; i < n; i++)
    {
        int x; cin >> x;
        InsertNode(t, x);
    }
}

void inorderLNR(TREE Root)
{
    if(Root != NULL) {
        inorderLNR(Root->pLeft);
        cout << Root->key << " ";
        inorderLNR(Root->pRight);
    }
    cout << endl;
}

void postorderLRN(TREE Root)
{
    if(Root != NULL) {
        postorderLRN(Root->pLeft);
        postorderLRN(Root->pRight);
        cout << Root->key << " ";
    }
    cout << endl;
}

void preorderNLR(TREE Root)
{
    if(Root != NULL) {
        cout << Root->key << " ";
        preorderNLR(Root->pLeft);
        preorderNLR(Root->pRight);

    }
    cout << endl;
}

void NRL(TREE Root)
{
    if(Root != NULL) {
        cout << Root->key << " ";
        NRL(Root->pRight);
        NRL(Root->pLeft);
    }
    cout << endl;
}


void RNL(TREE Root)
{
    if(Root != NULL) {
        RNL(Root->pRight);
        cout << Root->key << " ";
        RNL(Root->pLeft);
    }
    cout << endl;
}


void RLN(TREE Root)
{
    if(Root != NULL) {
        RLN(Root->pRight);
        RLN(Root->pLeft);
        cout << Root->key << " ";
    }
    cout << endl;
}

bool Search(TREE t, int x)
{
    if(t != NULL)
    {
        if(t->key == x) {
            return true;
        }
        if(t->key > x)
        {
            return Search(t->pLeft, x);
        }
        else
        {
            return Search(t->pRight, x);
        }
    }
    return false;
}

bool checkNodeSiblings(TREE t, int a, int b)
{
    if(t == NULL || (t->pLeft == NULL && t->pRight == NULL))
    {
        return false;
    }
    if(a == b)
    {
        return false;
    }
    if(t->pLeft != NULL && t->pRight != NULL)
    {
        if((t->pLeft->key == a && t->pRight->key == b) || (t->pLeft->key == b && t->pRight->key == a))
        {
            return true;
        }
    }
    if(a < t->key && b < t->key)
    {
        return checkNodeSiblings(t->pLeft, a, b);
    }
    if(a > t->key && b > t->key)
    {
        return checkNodeSiblings(t->pRight, a, b);
    }
    return false;
}

int cntNodes(TREE t)
{
    if(t == NULL) return 0;
    return 1 + cntNodes(t->pLeft) + cntNodes(t->pRight);
}

int cntLeaf(TREE t)
{
    if(t == NULL) return 0;
    if(t->pLeft == NULL && t->pRight == NULL) return 1;
    return cntLeaf(t->pLeft) + cntLeaf(t->pRight);
}

int cnt1Child(TREE t)
{
    if(t == NULL) return 0;
    int cnt = ((t->pLeft != NULL) != (t->pRight != NULL));
    return cnt + cnt1Child(t->pLeft) + cnt1Child(t->pRight);
}

int cntFullNode(TREE t)
{
    if(t == NULL) return 0;
    int cnt = (t->pLeft != NULL && t->pRight != NULL);
    return cnt + cntFullNode(t->pLeft) + cntFullNode(t->pRight);
}

int cntEven(TREE t)
{
    if(t == NULL ) return 0;
    int cnt = 0;
    if(t->key % 2 == 0) cnt++;
    return cnt + cntEven(t->pLeft) + cntEven(t->pRight);
}

int cntEvenLeaf(TREE t)
{
    if(t == NULL) return 0;
    int cnt =  0;
    if(t->pLeft == NULL && t->pRight == NULL && t->key % 2 == 0) cnt = 1;
    if(t->pLeft != NULL && t->pRight == NULL)
    {
        return cnt + cntEvenLeaf(t->pLeft) + cntEvenLeaf(t->pRight);
    }
    return cnt;
}

long long Sum(TREE t)
{
    if(t == NULL) return 0;
    return t->key + Sum(t->pLeft) + Sum(t->pRight);
}

long long sum1(TREE t)
{
    if(t == NULL) return 0;
    int cnt = 0;
    if((t->pLeft != NULL) != (t->pRight != NULL))
    {
        cnt = t->key;
    }
    return cnt + sum1(t->pLeft) + sum1(t->pRight);
}

long long sum1Prime(TREE t)
{
    if(t == NULL) return 0;
    int cnt = 0;
    if((t->pLeft != NULL) != (t->pRight != NULL))
    {
        if(check(t->key))
        {
            cnt = t->key;
        }
    }
    return cnt + sum1Prime(t->pLeft) + sum1Prime(t->pRight);
}

int height(TREE t)
{
    if(t == NULL) return -1;
    int lHeight = height(t->pLeft);
    int rHeight = height(t->pRight);
    return 1 + max(lHeight, rHeight);
}

TNode* findMin(TREE t)
{
    if(t == NULL) return NULL;
    while(t->pLeft != NULL)
    {
        t = t->pLeft;
    }
    return t;
}

int DeleteNode(TREE &t, int x)
{
    if(t == NULL) return 0;
    if(x < t->key)
    {
        return DeleteNode(t->pLeft, x);
    } else if(x > t->key)
    {
        return DeleteNode(t->pRight, x);
    }
    else
    {
        TNode *p = t;
        if(t->pLeft == NULL)
        {
            t = t->pRight;
        }
        else if(t->pRight == NULL)
        {
            t = t->pLeft;
        }
        else
        {
            TNode *pMin = findMin(t->pRight);
            t->key = pMin->key;
            int res = DeleteNode(t->pRight, pMin->key);
            return res;
        }
        if(p != t) delete p;
        return 1;
    }
}

bool checkIndentical(TREE t1, TREE t2)
{
    if(t1 == NULL && t2 == NULL) return true;
    if((t1 == NULL && t2 != NULL) || (t1 != NULL && t2 == NULL)) return false;
    return (t1->key == t2->key) &&
            checkIndentical(t1->pLeft, t2->pLeft) &&
            checkIndentical(t1->pRight, t2->pRight);
}




